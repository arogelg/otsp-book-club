import { neon } from '@netlify/neon';
export const sql = neon(); // Uses NETLIFY_DATABASE_URL injected by Netlify ↔ Neon
